public class VarietalBlend extends Beverage{
    public VarietalBlend(){
        description = "Varietal Blend";
    }

    public double cost(){
        return 1.50;
    }
}
